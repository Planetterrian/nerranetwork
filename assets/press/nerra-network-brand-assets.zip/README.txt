Nerra Network brand assets

Free to use in coverage of Nerra Network with a link to https://nerranetwork.com. Please keep the logos unaltered: no recolouring, stretching or combining with other marks. Use the PNG files unless your tool has DM Sans installed: the SVGs set their tagline in that font.

Colours: purple #6B47FF, cyan #00D4FF, night #0B0F1A.
Type: DM Sans (headings), Source Serif 4 (body).

The full media kit, updated as the network grows: https://nerranetwork.com/press.html
